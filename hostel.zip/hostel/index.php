
<?php
// Homepage for the Hostel Docket System
$schoolName = "Kogi State College of Nursing Sciences";
$campus = "Obangede";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hostel Docket System | <?= htmlspecialchars($schoolName) ?></title>

<style>
:root {
    --green: #075c35;
    --dark-green: #034326;
    --light: #f3f7f4;
    --white: #ffffff;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    background: var(--light);
    color: #26332b;
}

header {
    background: var(--green);
    color: var(--white);
    padding: 18px 5%;
    display: flex;
    align-items: center;
    gap: 16px;
}

.logo {
    width: 75px;
    height: 75px;
    object-fit: contain;
    background: white;
    border-radius: 50%;
    padding: 5px;
}

.school-name h1 {
    font-size: 20px;
    margin: 0 0 6px;
}

.school-name p {
    margin: 0;
    font-size: 14px;
}

nav {
    background: var(--dark-green);
    padding: 14px 5%;
}

nav a {
    color: white;
    text-decoration: none;
    margin-right: 24px;
    font-size: 14px;
}

.hero {
    text-align: center;
    padding: 55px 20px 45px;
    background: linear-gradient(135deg, #e6f2e9, #ffffff);
}

.hero h2 {
    color: var(--green);
    font-size: 32px;
    margin: 0 0 15px;
}

.hero p {
    max-width: 650px;
    margin: 0 auto 25px;
    line-height: 1.7;
}

.container {
    max-width: 1050px;
    margin: 35px auto;
    padding: 0 20px;
}

.cards {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 22px;
}

.card {
    background: white;
    border-radius: 10px;
    padding: 28px;
    border: 1px solid #dce6df;
    box-shadow: 0 4px 15px rgba(0,0,0,.04);
}

.card-icon {
    font-size: 35px;
}

.card h3 {
    color: var(--green);
    margin-bottom: 10px;
}

.card p {
    line-height: 1.6;
    color: #59645d;
}

.btn {
    display: inline-block;
    padding: 12px 20px;
    margin-top: 10px;
    background: var(--green);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
}

.btn:hover {
    background: var(--dark-green);
}

.notice {
    margin-top: 25px;
    background: #fff8e5;
    border-left: 4px solid #d39b18;
    padding: 16px;
    line-height: 1.6;
}

footer {
    background: #172c20;
    color: white;
    text-align: center;
    padding: 24px 15px;
    margin-top: 50px;
    font-size: 13px;
    line-height: 1.8;
}

@media (max-width: 650px) {
    header {
        padding: 15px;
    }

    .logo {
        width: 60px;
        height: 60px;
    }

    .school-name h1 {
        font-size: 16px;
    }

    nav a {
        display: inline-block;
        margin: 5px 12px 5px 0;
    }

    .hero h2 {
        font-size: 25px;
    }

    .cards {
        grid-template-columns: 1fr;
    }
}
</style>
</head>

<body>

<header>
    <img
        src="assets/school-logo.png"
        alt="College Logo"
        class="logo"
        onerror="this.style.display='none'"
    >

    <div class="school-name">
        <h1><?= htmlspecialchars($schoolName) ?></h1>
        <p><?= htmlspecialchars($campus) ?> Campus</p>
    </div>
</header>

<nav>
    <a href="index.php">Home</a>
    <a href="hostel_docket.php">Hostel Docket</a>
</nav>

<section class="hero">
    <h2>Hostel Docket Portal</h2>

    <p>
        Welcome to the hostel docket portal of
        <?= htmlspecialchars($schoolName) ?>,
        <?= htmlspecialchars($campus) ?>.
        Generate your hostel payment docket and verify
        your payment details conveniently.
    </p>

    <a class="btn" href="hostel_docket.php">
        Generate Hostel Docket
    </a>
</section>

<main class="container">
    <div class="cards">

        <section class="card">
            <div class="card-icon">📄</div>
            <h3>Hostel Payment Docket</h3>

            <p>
                Retrieve your confirmed hostel payment record
                and print your hostel docket slip.
            </p>

            <a class="btn" href="hostel_docket.php">
                Generate Docket
            </a>
        </section>

        <section class="card">
            <div class="card-icon">📱</div>
            <h3>QR Code Verification</h3>

            <p>
                Verify a hostel docket by scanning its QR code
                or opening the verification page.
            </p>

            <a class="btn" href="verify_hostel.php">
                Verify Docket
            </a>
        </section>

    </div>

    <div class="notice">
        <strong>Important Notice:</strong>
        Only confirmed hostel payments can generate a valid
        payment docket. Contact the appropriate school office
        if your payment has not been confirmed.
    </div>
</main>

<footer>
    <strong><?= htmlspecialchars($schoolName) ?></strong><br>
    <?= htmlspecialchars($campus) ?> Campus<br>
    Hostel Docket Management System<br>
    Design by ICT Department
</footer>

</body>
</html>
