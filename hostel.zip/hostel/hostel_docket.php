<?php
$conn = new mysqli(
    "localhost",
    "root",
    "",
    "school_portal"
);

if ($conn->connect_error) {
    die("Database connection failed.");
}

$conn->set_charset("utf8mb4");

$student = null;
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $matric = trim($_POST["matric_no"] ?? "");

    if ($matric === "") {
        $error = "Enter your matriculation number.";
    } else {
        $stmt = $conn->prepare(
            "SELECT * FROM hostel_payments
             WHERE matric_no = ?
             AND status = 'PAID'
             ORDER BY id DESC LIMIT 1"
        );

        $stmt->bind_param("s", $matric);
        $stmt->execute();

        $result = $stmt->get_result();
        $student = $result->fetch_assoc();

        if (!$student) {
            $error = "No confirmed hostel payment was found.";
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport"
      content="width=device-width, initial-scale=1">
<title>Hostel Docket Slip</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #f2f4f7;
    margin: 0;
    padding: 20px;
}
.container {
    max-width: 750px;
    margin: auto;
}
.search, .docket {
    background: white;
    padding: 25px;
    margin-bottom: 20px;
    border-radius: 8px;
}
input, button {
    padding: 12px;
    margin-top: 10px;
    box-sizing: border-box;
}
input {
    width: 100%;
}
button {
    cursor: pointer;
    border: 0;
    background: #075c35;
    color: white;
    border-radius: 4px;
}
.error {
    color: #b00020;
}
.header {
    text-align: center;
    border-bottom: 2px solid #075c35;
    padding-bottom: 12px;
}
.header h2 {
    margin-bottom: 5px;
}
.row {
    padding: 10px 0;
    border-bottom: 1px solid #ddd;
}
.label {
    font-weight: bold;
}
.signatures {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    margin-top: 45px;
}
.signatures div {
    width: 45%;
    border-top: 1px solid #333;
    text-align: center;
    padding-top: 8px;
}
@media print {
    body {
        background: white;
        padding: 0;
    }
    .search, .no-print {
        display: none !important;
    }
    .docket {
        border: 1px solid #333;
        border-radius: 0;
        margin: 0;
    }
}
@media print {
    .qr-section {
        display: block !important;
        break-inside: avoid;
    }
}
.school-logo {
    width: 95px;
    height: 95px;
    object-fit: contain;
    display: block;
    margin: 0 auto 10px;
}

.header {
    text-align: center;
    border-bottom: 2px solid #075c35;
    padding-bottom: 12px;
}

@media print {
    .school-logo {
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
    }
}

.ict-credit {
    text-align: center;
    margin-top: 25px;
    padding-top: 10px;
    border-top: 1px solid #ddd;
    font-size: 11px;
    font-weight: bold;
    color: #075c35;
    letter-spacing: 0.5px;
}

@media print {
    .ict-credit {
        display: block !important;
        color: #075c35 !important;
    }
}

</style>
</head>

<body>
<div class="container">

<div class="search">
    <h2>Hostel Docket Slip</h2>

    <form method="POST">
        <label>Matriculation Number</label>
        <input type="text" name="matric_no"
               placeholder="Enter matriculation number"
               required>
        <button type="submit">Generate Docket</button>
    </form>

    <?php if ($error): ?>
        <p class="error">
            <?= htmlspecialchars($error) ?>
        </p>
    <?php endif; ?>
</div>

<?php if ($student): ?>
<div class="docket">

    
<div class="header">
    <img
        src="assets/school-logo.png"
        alt="College Logo"
        class="school-logo"
    >

    <h2>KOGI STATE COLLEGE OF NURSING SCIENCES</h2>
    <h3>OBANGEDE</h3>
    <h3>HOSTEL PAYMENT DOCKET SLIP</h3>

    <p>
        Academic Session:
        <?= htmlspecialchars($student["session"] ?? "") ?>
    </p>
</div>


    <?php
    $fields = [
        "Student Name" => "student_name",
        "Matriculation Number" => "matric_no",
        "Department" => "department",
        "Level" => "level",
        "Hostel Name" => "hostel_name",
        "Room Number" => "room_no",
        "Bed Space" => "bed_space",
        "Payment Reference" => "payment_ref",
        "Payment Date" => "payment_date"
    ];

    foreach ($fields as $label => $key):
    ?>
        <div class="row">
            <span class="label">
                <?= htmlspecialchars($label) ?>:
            </span>
            <?= htmlspecialchars(
                (string)($student[$key] ?? "")
            ) ?>
        </div>
    <?php endforeach; ?>

    <div class="row">
        <span class="label">Amount Paid:</span>
        ₦<?= number_format((float)$student["amount"], 2) ?>
    </div>

    <div class="row">
        <span class="label">Payment Status:</span>
        PAID
    </div>

<div class="qr-section" style="text-align:center; margin-top:25px;">
    <h3>SCAN TO VERIFY PAYMENT</h3>

    <div id="qrcode"
         style="display:flex; justify-content:center;">
    </div>

    <p style="font-size:12px;">
        Docket No: HST-<?= (int)$student["id"] ?>
    </p>

    <p style="font-size:11px;">
        Scan this QR code to verify hostel payment.
    </p>
</div>

    <div class="signatures">
        <div>Student's Signature</div>
        <div>Hostel Officer</div>
    </div>

    <p style="text-align:center; margin-top:30px;">
        This docket is valid only for the recorded hostel payment.
    </p>

    <div class="no-print" style="text-align:center">
        <button onclick="window.print()">Print Docket</button>
    </div>
</div>
<?php endif; ?>

</div>

<div class="ict-credit">
    Design by ICT Department
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

<?php if ($student): ?>
<script>
const verificationUrl =
    window.location.origin +
    window.location.pathname.replace(
        /[^/]*$/,
        "verify_hostel.php"
    ) +
    "?id=" +
    <?= json_encode((string)$student["id"]) ?>;

new QRCode(document.getElementById("qrcode"), {
    text: verificationUrl,
    width: 150,
    height: 150,
    correctLevel: QRCode.CorrectLevel.M
});
</script>
<?php endif; ?>
</body>
</html>