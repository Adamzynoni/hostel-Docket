
<?php
$conn = new mysqli(
    "localhost",
    "root",
    "",
    "school_portal"
);

if ($conn->connect_error) {
    http_response_code(500);
    exit("Verification service unavailable.");
}

$conn->set_charset("utf8mb4");

$student = null;
$error = "";
$search = "";
$searched = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $search = trim($_POST["verification_input"] ?? "");
    $searched = true;
} else {
    // Support QR codes that open verify_hostel.php?id=123
    $id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

    if ($id && $id > 0) {
        $search = (string)$id;
        $searched = true;
    }
}

if ($searched) {
    if ($search === "") {
        $error = "Enter a docket ID, matric number, or payment reference.";
    } else {
        /*
         * Search by numeric docket ID, matric number,
         * or payment reference.
         */
        if (ctype_digit($search) && (int)$search > 0) {
            $stmt = $conn->prepare(
                "SELECT * FROM hostel_payments
                 WHERE id = ?
                    OR matric_no = ?
                    OR payment_ref = ?
                 LIMIT 1"
            );

            $idSearch = (int)$search;
            $stmt->bind_param(
                "iss",
                $idSearch,
                $search,
                $search
            );
        } else {
            $stmt = $conn->prepare(
                "SELECT * FROM hostel_payments
                 WHERE matric_no = ?
                    OR payment_ref = ?
                 ORDER BY id DESC
                 LIMIT 1"
            );

            $stmt->bind_param("ss", $search, $search);
        }

        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$student) {
            $error = "No docket record found. Check your details and try again.";
        }
    }
}

$conn->close();

function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

$valid = $student &&
    strtoupper(trim($student["status"])) === "PAID";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport"
      content="width=device-width, initial-scale=1">

<title>Hostel Docket Verification</title>

<style>
* {
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f1f4f2;
    margin: 0;
    padding: 20px;
    color: #26332b;
}

.card {
    max-width: 580px;
    margin: 25px auto;
    padding: 25px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 3px 15px rgba(0,0,0,.08);
}

.header {
    text-align: center;
    border-bottom: 2px solid #075c35;
    padding-bottom: 18px;
    margin-bottom: 22px;
}

.logo {
    width: 90px;
    height: 90px;
    object-fit: contain;
    margin-bottom: 10px;
}

h2 {
    color: #075c35;
    margin: 5px 0;
    font-size: 22px;
}

h3 {
    margin-top: 8px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
}

input {
    width: 100%;
    padding: 13px;
    border: 1px solid #bbc9bf;
    border-radius: 6px;
    font-size: 16px;
}

button {
    width: 100%;
    margin-top: 12px;
    padding: 13px;
    border: none;
    border-radius: 6px;
    background: #075c35;
    color: white;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background: #034326;
}

.status {
    padding: 13px;
    border-radius: 5px;
    background: #e8f5e9;
    color: #075c35;
    font-weight: bold;
    text-align: center;
    margin-bottom: 15px;
}

.unverified {
    background: #ffebee;
    color: #b00020;
}

.row {
    padding: 11px 0;
    border-bottom: 1px solid #e1e6e2;
    overflow-wrap: anywhere;
}

.row b {
    display: inline-block;
    margin-right: 5px;
}

.message {
    color: #b00020;
    background: #fff0f0;
    padding: 12px;
    border-radius: 5px;
    line-height: 1.5;
}

footer {
    margin-top: 25px;
    padding-top: 15px;
    border-top: 1px solid #ddd;
    color: #075c35;
    text-align: center;
    font-size: 12px;
    font-weight: bold;
}

.home {
    display: inline-block;
    margin-top: 18px;
    color: #075c35;
    text-decoration: none;
}
</style>
</head>

<body>
<div class="card">

    <div class="header">
        <img
            src="assets/school-logo.png"
            alt="College Logo"
            class="logo"
            onerror="this.style.display='none'"
        >

        <h2>Kogi State College of Nursing Sciences</h2>
        <h3>Obangede</h3>
        <p>HOSTEL DOCKET VERIFICATION</p>
    </div>

    <form method="POST" action="verify_hostel.php">
        <label for="verification_input">
            Enter Verification Details
        </label>

        <input
            type="text"
            id="verification_input"
            name="verification_input"
            value="<?= e($search) ?>"
            placeholder="Docket ID, Matric Number or Payment Reference"
            required
            autocomplete="off"
        >

        <button type="submit">
            Verify Hostel Payment
        </button>
    </form>

    <?php if ($error): ?>
        <p class="message"><?= e($error) ?></p>
    <?php endif; ?>

    <?php if ($student): ?>

        <?php if ($valid): ?>
            <h3>Verification Result</h3>
            <div class="status">✓ PAYMENT VERIFIED</div>

            <div class="row">
                <b>Docket ID:</b>
                HST-<?= (int)$student["id"] ?>
            </div>

            <div class="row">
                <b>Student Name:</b>
                <?= e($student["student_name"]) ?>
            </div>

            <div class="row">
                <b>Matric Number:</b>
                <?= e($student["matric_no"]) ?>
            </div>

            <div class="row">
                <b>Academic Session:</b>
                <?= e($student["session"] ?? "") ?>
            </div>

            <div class="row">
                <b>Hostel:</b>
                <?= e($student["hostel_name"] ?? "") ?>
            </div>

            <div class="row">
                <b>Room Number:</b>
                <?= e($student["room_no"] ?? "") ?>
            </div>

            <div class="row">
                <b>Payment Reference:</b>
                <?= e($student["payment_ref"]) ?>
            </div>

            <div class="row">
                <b>Amount Paid:</b>
                ₦<?= number_format(
                    (float)$student["amount"], 2
                ) ?>
            </div>

            <div class="row">
                <b>Payment Date:</b>
                <?= e($student["payment_date"] ?? "") ?>
            </div>

        <?php else: ?>
            <h3>Verification Result</h3>
            <div class="status unverified">
                PAYMENT NOT VERIFIED
            </div>
            <p>
                A docket record exists, but its status is not
                confirmed as PAID. Contact the appropriate office.
            </p>
        <?php endif; ?>

    <?php endif; ?>

    <div style="text-align:center">
        <a class="home" href="index.php">← Back to Homepage</a>
    </div>

    <footer>
        Design by ICT Department
    </footer>

</div>
</body>
</html>
